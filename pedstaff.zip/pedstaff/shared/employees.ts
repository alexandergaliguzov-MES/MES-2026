import { z } from "zod";

export const programCodes = ["NOO", "OOO", "SOO"] as const;
export const educationLevels = ["higher", "secondary_special", "none"] as const;
export const qualificationCategories = ["first", "highest", "none"] as const;
export const academicDegrees = ["candidate", "doctor"] as const;
export const academicTitles = ["associate_professor", "professor"] as const;
export const employeeStatuses = ["draft", "complete"] as const;

export const courseMonthNames = [
  "январь", "февраль", "март", "апрель", "май", "июнь",
  "июль", "август", "сентябрь", "октябрь", "ноябрь", "декабрь",
] as const;
const coursePeriodPattern = new RegExp(`^(${courseMonthNames.join("|")}),\\s*(2024|2025|2026)$`, "u");
const legacyCoursePeriodPattern = /^(2024|2025|2026)-(0[1-9]|1[0-2])$/;

export function isCoursePeriod(value: string) {
  return coursePeriodPattern.test(value.trim().toLocaleLowerCase("ru-RU"));
}

/** Makes legacy YYYY-MM values readable in the new month-name input without altering invalid data. */
export function formatCoursePeriod(value: string) {
  const normalized = value.trim().toLocaleLowerCase("ru-RU");
  if (isCoursePeriod(normalized)) return normalized.replace(/,\s*/, ", ");
  const legacy = legacyCoursePeriodPattern.exec(normalized);
  if (!legacy) return value;
  const [, year, month] = legacy;
  return `${courseMonthNames[Number(month) - 1]}, ${year}`;
}

export const courseSchema = z.object({
  monthYear: z.string().max(16),
  courseName: z.string().max(300),
  hours: z.number().int().nullable(),
});

export const employeeFormSchema = z
  .object({
    programs: z.array(z.enum(programCodes)).default([]),
    surname: z.string().max(120).default(""),
    firstName: z.string().max(120).default(""),
    middleName: z.string().max(120).default(""),
    position: z.string().max(180).default(""),
    subjects: z.string().max(500).default(""),
    education: z.enum(educationLevels).nullable().default(null),
    qualificationCategory: z.enum(qualificationCategories).nullable().default(null),
    categoryAssignedAt: z.string().max(10).default(""),
    categoryOrderNumber: z.string().max(120).default(""),
    academicDegree: z.enum(academicDegrees).nullable().default(null),
    degreeField: z.string().max(180).default(""),
    degreeDiploma: z.string().max(180).default(""),
    academicTitle: z.enum(academicTitles).nullable().default(null),
    stateAwards: z.string().max(1200).default(""),
    sportsAwards: z.string().max(1200).default(""),
    courses: z.array(courseSchema).max(100).default([]),
    status: z.enum(employeeStatuses).default("draft"),
  })
  .superRefine((employee, context) => {
    employee.courses.forEach((course, index) => {
      if (course.hours !== null && course.hours < 24) {
        context.addIssue({
          code: "custom",
          path: ["courses", index, "hours"],
          message: "Курсы менее 24 часов не указывать (!!!)",
        });
      }
      if (course.monthYear && !isCoursePeriod(course.monthYear)) {
        context.addIssue({
          code: "custom",
          path: ["courses", index, "monthYear"],
          message: "Укажите месяц и год в формате «июль, 2026» за период 2024–2026.",
        });
      }
      if (course.hours !== null && course.hours <= 0) {
        context.addIssue({
          code: "custom",
          path: ["courses", index, "hours"],
          message: "Укажите корректное количество часов.",
        });
      }
    });

    if (employee.status !== "complete") return;

    const required: Array<[keyof typeof employee, string]> = [
      ["surname", "Укажите фамилию."],
      ["firstName", "Укажите имя."],
      ["position", "Укажите должность."],
      ["subjects", "Укажите преподаваемые предметы, курсы или модули."],
    ];
    for (const [field, message] of required) {
      if (typeof employee[field] === "string" && !employee[field].trim()) {
        context.addIssue({ code: "custom", path: [field], message });
      }
    }
    if (!employee.programs.length) {
      context.addIssue({ code: "custom", path: ["programs"], message: "Выберите хотя бы одну программу." });
    }
    if (!employee.education) {
      context.addIssue({ code: "custom", path: ["education"], message: "Выберите уровень образования." });
    }
    if (!employee.qualificationCategory) {
      context.addIssue({ code: "custom", path: ["qualificationCategory"], message: "Выберите квалификационную категорию." });
    }
    if (["first", "highest"].includes(employee.qualificationCategory ?? "")) {
      if (!employee.categoryAssignedAt) {
        context.addIssue({ code: "custom", path: ["categoryAssignedAt"], message: "Укажите дату присвоения категории." });
      }
      if (employee.categoryAssignedAt) {
        const assignedAt = new Date(`${employee.categoryAssignedAt}T00:00:00.000Z`);
        if (!/^\d{4}-\d{2}-\d{2}$/.test(employee.categoryAssignedAt) || Number.isNaN(assignedAt.getTime()) || assignedAt.toISOString().slice(0, 10) !== employee.categoryAssignedAt) {
          context.addIssue({ code: "custom", path: ["categoryAssignedAt"], message: "Укажите корректную дату присвоения категории." });
        }
      }
      if (!employee.categoryOrderNumber.trim()) {
        context.addIssue({ code: "custom", path: ["categoryOrderNumber"], message: "Укажите номер приказа." });
      }
    }
    if (employee.academicDegree) {
      if (!employee.degreeField.trim()) {
        context.addIssue({ code: "custom", path: ["degreeField"], message: "Укажите отрасль науки." });
      }
      if (!employee.degreeDiploma.trim()) {
        context.addIssue({ code: "custom", path: ["degreeDiploma"], message: "Укажите сведения о дипломе." });
      }
    }
    employee.courses.forEach((course, index) => {
      const hasAnyValue = course.monthYear || course.courseName.trim() || course.hours !== null;
      if (!hasAnyValue) return;
      if (!isCoursePeriod(course.monthYear)) {
        context.addIssue({ code: "custom", path: ["courses", index, "monthYear"], message: "Укажите месяц и год в формате «июль, 2026»." });
      }
      if (!course.courseName.trim()) {
        context.addIssue({ code: "custom", path: ["courses", index, "courseName"], message: "Укажите название курса." });
      }
      if (course.hours === null || course.hours < 24) {
        context.addIssue({ code: "custom", path: ["courses", index, "hours"], message: "Укажите не менее 24 часов." });
      }
    });
  });

export type EmployeeFormData = z.infer<typeof employeeFormSchema>;
export type EmployeeStatus = (typeof employeeStatuses)[number];

export type EmployeeRecord = EmployeeFormData & {
  id: number;
  createdAt: Date;
  updatedAt: Date;
};

export const emptyEmployeeForm = (): EmployeeFormData => ({
  programs: [],
  surname: "",
  firstName: "",
  middleName: "",
  position: "",
  subjects: "",
  education: null,
  qualificationCategory: null,
  categoryAssignedAt: "",
  categoryOrderNumber: "",
  academicDegree: null,
  degreeField: "",
  degreeDiploma: "",
  academicTitle: null,
  stateAwards: "",
  sportsAwards: "",
  courses: [],
  status: "draft",
});

export function completionPercent(employee: EmployeeFormData): number {
  const checks = [
    employee.programs.length > 0,
    Boolean(employee.surname.trim()),
    Boolean(employee.firstName.trim()),
    Boolean(employee.position.trim()),
    Boolean(employee.subjects.trim()),
    Boolean(employee.education),
    Boolean(employee.qualificationCategory),
  ];
  if (employee.qualificationCategory === "first" || employee.qualificationCategory === "highest") {
    checks.push(Boolean(employee.categoryAssignedAt), Boolean(employee.categoryOrderNumber.trim()));
  }
  if (employee.academicDegree) {
    checks.push(Boolean(employee.degreeField.trim()), Boolean(employee.degreeDiploma.trim()));
  }
  const complete = checks.filter(Boolean).length;
  return Math.round((complete / checks.length) * 100);
}

export const programLabels: Record<(typeof programCodes)[number], string> = {
  NOO: "НОО",
  OOO: "ООО",
  SOO: "СОО",
};
