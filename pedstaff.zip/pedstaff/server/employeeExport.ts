import { fileURLToPath } from "node:url";
import {
  AlignmentType,
  BorderStyle,
  Document,
  HeadingLevel,
  Packer,
  Paragraph,
  ShadingType,
  Table,
  TableCell,
  TableRow,
  TextRun,
  WidthType,
} from "docx";
import PDFDocument from "pdfkit";
import { programLabels, type EmployeeFormData, type EmployeeRecord } from "../shared/employees";

export type EmployeeExportFormat = "docx" | "pdf";

const COLORS = {
  burgundy: "762B3E",
  blue: "244F78",
  gray: "52616F",
  lightGray: "EDF0F3",
  border: "CBD3DB",
  white: "FFFFFF",
};
const PDF_FONT = "SchoolSans";
const PDF_FONT_PATH = fileURLToPath(new URL("./assets/DejaVuSans.ttf", import.meta.url));

const educationLabels: Record<NonNullable<EmployeeFormData["education"]>, string> = {
  higher: "Высшее",
  secondary_special: "Среднее специальное",
  none: "Без образования",
};
const categoryLabels: Record<NonNullable<EmployeeFormData["qualificationCategory"]>, string> = {
  first: "Первая",
  highest: "Высшая",
  none: "Отсутствует",
};
const degreeLabels = { candidate: "Кандидат наук", doctor: "Доктор наук" } as const;
const titleLabels = { associate_professor: "Доцент", professor: "Профессор" } as const;

function valueOrDash(value: string | number | null | undefined) {
  return value === null || value === undefined || String(value).trim() === "" ? "Не указано" : String(value).trim();
}

function fullName(employee: EmployeeRecord) {
  return [employee.surname, employee.firstName, employee.middleName].filter(Boolean).join(" ") || "Сотрудник";
}

function formatDate(value: Date | string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "—" : new Intl.DateTimeFormat("ru-RU", { day: "2-digit", month: "2-digit", year: "numeric" }).format(date);
}

function employeeRows(employee: EmployeeRecord): Array<[string, string]> {
  const category = employee.qualificationCategory ? categoryLabels[employee.qualificationCategory] : "Не указано";
  const categoryDetails = [
    category,
    employee.qualificationCategory === "first" || employee.qualificationCategory === "highest"
      ? `дата присвоения: ${valueOrDash(employee.categoryAssignedAt)}; приказ: ${valueOrDash(employee.categoryOrderNumber)}`
      : "",
  ].filter(Boolean).join("; ");
  const degree = employee.academicDegree ? degreeLabels[employee.academicDegree] : "Не указано";
  const degreeDetails = employee.academicDegree
    ? `${degree}; отрасль науки: ${valueOrDash(employee.degreeField)}; диплом: ${valueOrDash(employee.degreeDiploma)}`
    : degree;

  return [
    ["Фамилия", valueOrDash(employee.surname)],
    ["Имя", valueOrDash(employee.firstName)],
    ["Отчество", valueOrDash(employee.middleName)],
    ["Общеобразовательные программы", employee.programs.length ? employee.programs.map(program => programLabels[program]).join(", ") : "Не указано"],
    ["Занимаемая должность", valueOrDash(employee.position)],
    ["Преподаваемые предметы, курсы, модули", valueOrDash(employee.subjects)],
    ["Уровень образования", employee.education ? educationLabels[employee.education] : "Не указано"],
    ["Квалификационная категория", categoryDetails],
    ["Учёная степень", degreeDetails],
    ["Учёное звание", employee.academicTitle ? titleLabels[employee.academicTitle] : "Не указано"],
    ["Государственные и ведомственные награды", valueOrDash(employee.stateAwards)],
    ["Спортивные звания и награды", valueOrDash(employee.sportsAwards)],
  ];
}

function docxText(text: string, options: { bold?: boolean; color?: string; size?: number } = {}) {
  return new TextRun({ text, font: "Arial", size: options.size ?? 20, bold: options.bold, color: options.color });
}

function docxParagraph(text: string, options: { bold?: boolean; color?: string; size?: number; spacingAfter?: number; pageBreakBefore?: boolean } = {}) {
  return new Paragraph({
    children: [docxText(text, options)],
    spacing: { after: options.spacingAfter ?? 100 },
    pageBreakBefore: options.pageBreakBefore,
  });
}

function docxValueTable(rows: Array<[string, string]>) {
  const makeCell = (text: string, header = false) => new TableCell({
    width: { size: header ? 34 : 66, type: WidthType.PERCENTAGE },
    shading: header ? { type: ShadingType.CLEAR, color: COLORS.lightGray, fill: COLORS.lightGray } : undefined,
    margins: { top: 90, bottom: 90, left: 110, right: 110 },
    children: [new Paragraph({ children: [docxText(text, { bold: header, color: header ? COLORS.blue : "1F2933", size: 19 })] })],
  });
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 4, color: COLORS.border },
      bottom: { style: BorderStyle.SINGLE, size: 4, color: COLORS.border },
      left: { style: BorderStyle.SINGLE, size: 4, color: COLORS.border },
      right: { style: BorderStyle.SINGLE, size: 4, color: COLORS.border },
      insideHorizontal: { style: BorderStyle.SINGLE, size: 4, color: COLORS.border },
      insideVertical: { style: BorderStyle.SINGLE, size: 4, color: COLORS.border },
    },
    rows: rows.map(([label, value]) => new TableRow({ children: [makeCell(label, true), makeCell(value)] })),
  });
}

function docxCourses(employee: EmployeeRecord) {
  if (!employee.courses.length) return docxParagraph("Сведения о повышении квалификации не внесены.", { color: COLORS.gray, size: 19 });
  const cell = (text: string, header = false) => new TableCell({
    shading: header ? { type: ShadingType.CLEAR, color: COLORS.blue, fill: COLORS.blue } : undefined,
    margins: { top: 90, bottom: 90, left: 100, right: 100 },
    children: [new Paragraph({ children: [docxText(text, { bold: header, color: header ? COLORS.white : "1F2933", size: 18 })] })],
  });
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 4, color: COLORS.border },
      bottom: { style: BorderStyle.SINGLE, size: 4, color: COLORS.border },
      left: { style: BorderStyle.SINGLE, size: 4, color: COLORS.border },
      right: { style: BorderStyle.SINGLE, size: 4, color: COLORS.border },
      insideHorizontal: { style: BorderStyle.SINGLE, size: 4, color: COLORS.border },
      insideVertical: { style: BorderStyle.SINGLE, size: 4, color: COLORS.border },
    },
    rows: [
      new TableRow({ children: [cell("Месяц, год", true), cell("Название курса", true), cell("Количество часов", true)] }),
      ...employee.courses.map(course => new TableRow({
        children: [cell(valueOrDash(course.monthYear)), cell(valueOrDash(course.courseName)), cell(course.hours === null ? "Не указано" : `${course.hours} ч.`)],
      })),
    ],
  });
}

function docxCard(employee: EmployeeRecord, pageBreakBefore: boolean) {
  return [
    docxParagraph("МОСКОВСКАЯ ЭКОНОМИЧЕСКАЯ ШКОЛА", { bold: true, color: COLORS.burgundy, size: 20, pageBreakBefore }),
    new Paragraph({
      text: "Сведения о педагогическом работнике",
      heading: HeadingLevel.HEADING_1,
      spacing: { after: 120 },
      alignment: AlignmentType.LEFT,
    }),
    docxParagraph(fullName(employee), { bold: true, color: COLORS.blue, size: 28, spacingAfter: 80 }),
    docxParagraph(`Статус анкеты: ${employee.status === "complete" ? "Заполнена" : "Черновик"}. Создано: ${formatDate(employee.createdAt)}. Обновлено: ${formatDate(employee.updatedAt)}.`, { color: COLORS.gray, size: 18, spacingAfter: 220 }),
    docxParagraph("Общие сведения и квалификация", { bold: true, color: COLORS.burgundy, size: 22, spacingAfter: 80 }),
    docxValueTable(employeeRows(employee)),
    docxParagraph("Повышение квалификации", { bold: true, color: COLORS.burgundy, size: 22, spacingAfter: 80 }),
    docxCourses(employee),
  ];
}

export async function createEmployeeDocx(employees: EmployeeRecord[]) {
  const document = new Document({
    creator: "Московская экономическая школа",
    title: employees.length === 1 ? `Карточка сотрудника: ${fullName(employees[0])}` : "Карточки педагогических работников",
    sections: [{ properties: {}, children: employees.flatMap((employee, index) => docxCard(employee, index > 0)) }],
  });
  return Packer.toBuffer(document);
}

function ensurePdfSpace(document: PDFKit.PDFDocument, height: number) {
  const bottom = document.page.height - document.page.margins.bottom;
  if (document.y + height > bottom) document.addPage();
}

function pdfSection(document: PDFKit.PDFDocument, title: string) {
  ensurePdfSpace(document, 34);
  document.moveDown(0.55).font(PDF_FONT).fontSize(13).fillColor(`#${COLORS.burgundy}`).text(title);
  document.moveDown(0.2);
}

function pdfPair(document: PDFKit.PDFDocument, label: string, value: string) {
  document.font(PDF_FONT).fontSize(9);
  const labelHeight = document.heightOfString(label, { width: 505, lineGap: 1 });
  document.font(PDF_FONT).fontSize(10);
  const valueHeight = document.heightOfString(value, { width: 495, lineGap: 2 });
  ensurePdfSpace(document, labelHeight + valueHeight + 16);
  document.font(PDF_FONT).fontSize(9).fillColor(`#${COLORS.blue}`).text(label, { width: 505, lineGap: 1 });
  document.font(PDF_FONT).fontSize(10).fillColor("#1F2933").text(value, { indent: 10, width: 495, lineGap: 2 });
  document.moveDown(0.32);
}

function pdfCoursesHeader(document: PDFKit.PDFDocument) {
  ensurePdfSpace(document, 20);
  const y = document.y;
  document.font(PDF_FONT).fontSize(9).fillColor(`#${COLORS.blue}`).text("Месяц, год", 45, y, { width: 120 });
  document.text("Название курса", 175, y, { width: 270 });
  document.text("Часы", 455, y, { width: 70 });
  document.y = y + 17;
}

function pdfCourses(document: PDFKit.PDFDocument, employee: EmployeeRecord) {
  if (!employee.courses.length) {
    ensurePdfSpace(document, 28);
    document.font(PDF_FONT).fontSize(10).fillColor(`#${COLORS.gray}`).text("Сведения о повышении квалификации не внесены.");
    return;
  }
  pdfCoursesHeader(document);
  for (const course of employee.courses) {
    const period = valueOrDash(course.monthYear);
    const courseName = valueOrDash(course.courseName);
    const hours = course.hours === null ? "—" : `${course.hours} ч.`;
    document.font(PDF_FONT).fontSize(9);
    const rowHeight = Math.max(
      document.heightOfString(period, { width: 120, lineGap: 1 }),
      document.heightOfString(courseName, { width: 270, lineGap: 1 }),
      document.heightOfString(hours, { width: 70, lineGap: 1 }),
      13,
    ) + 10;
    const bottom = document.page.height - document.page.margins.bottom;
    if (document.y + rowHeight > bottom) {
      document.addPage();
      pdfCoursesHeader(document);
    }
    const y = document.y;
    document.font(PDF_FONT).fontSize(9).fillColor("#1F2933").text(period, 45, y, { width: 120, lineGap: 1 });
    document.text(courseName, 175, y, { width: 270, lineGap: 1 });
    document.text(hours, 455, y, { width: 70, lineGap: 1 });
    document.y = y + rowHeight;
  }
}

function drawPdfCard(document: PDFKit.PDFDocument, employee: EmployeeRecord, pageBreakBefore: boolean) {
  if (pageBreakBefore) document.addPage();
  document.font(PDF_FONT).fontSize(10).fillColor(`#${COLORS.burgundy}`).text("МОСКОВСКАЯ ЭКОНОМИЧЕСКАЯ ШКОЛА");
  document.font(PDF_FONT).fontSize(18).fillColor(`#${COLORS.blue}`).text("Сведения о педагогическом работнике");
  document.moveDown(0.25);
  document.font(PDF_FONT).fontSize(16).fillColor("#1F2933").text(fullName(employee));
  document.font(PDF_FONT).fontSize(9).fillColor(`#${COLORS.gray}`).text(`Статус анкеты: ${employee.status === "complete" ? "Заполнена" : "Черновик"}. Создано: ${formatDate(employee.createdAt)}. Обновлено: ${formatDate(employee.updatedAt)}.`);
  pdfSection(document, "Общие сведения и квалификация");
  for (const [label, value] of employeeRows(employee)) pdfPair(document, label, value);
  pdfSection(document, "Повышение квалификации");
  pdfCourses(document, employee);
}

export async function createEmployeePdf(employees: EmployeeRecord[]): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const document = new PDFDocument({ size: "A4", margins: { top: 46, bottom: 46, left: 45, right: 45 }, info: { Title: "Карточки педагогических работников", Author: "Московская экономическая школа" } });
    const chunks: Buffer[] = [];
    document.registerFont(PDF_FONT, PDF_FONT_PATH);
    document.on("data", (chunk: Buffer) => chunks.push(chunk));
    document.on("end", () => resolve(Buffer.concat(chunks)));
    document.on("error", reject);
    employees.forEach((employee, index) => drawPdfCard(document, employee, index > 0));
    document.end();
  });
}

export function exportFileName(format: EmployeeExportFormat, employees: EmployeeRecord[]) {
  const extension = format === "docx" ? "docx" : "pdf";
  return employees.length === 1 ? `employee_card_${employees[0].id}.${extension}` : `employee_cards_${employees.length}.${extension}`;
}
