import { describe, expect, it } from "vitest";
import { emptyEmployeeForm, employeeFormSchema } from "../shared/employees";

const completeProfile = {
  ...emptyEmployeeForm(),
  programs: ["NOO", "SOO"] as const,
  surname: "Иванова",
  firstName: "Мария",
  position: "Учитель",
  subjects: "Русский язык, литература",
  education: "higher" as const,
  qualificationCategory: "first" as const,
  categoryAssignedAt: "2026-09-01",
  categoryOrderNumber: "125-к",
  status: "complete" as const,
};

describe("employee form validation", () => {
  it("allows a blank draft and a complete profile with multiple programs", () => {
    expect(employeeFormSchema.safeParse(emptyEmployeeForm()).success).toBe(true);
    const parsed = employeeFormSchema.safeParse(completeProfile);
    expect(parsed.success).toBe(true);
    if (parsed.success) expect(parsed.data.programs).toEqual(["NOO", "SOO"]);
  });

  it("requires assignment date and order number for first or highest category", () => {
    const parsed = employeeFormSchema.safeParse({
      ...completeProfile,
      categoryAssignedAt: "",
      categoryOrderNumber: "",
    });
    expect(parsed.success).toBe(false);
    if (!parsed.success) {
      const fields = parsed.error.issues.map(issue => issue.path[0]);
      expect(fields).toContain("categoryAssignedAt");
      expect(fields).toContain("categoryOrderNumber");
    }
  });

  it("rejects an impossible category assignment date", () => {
    const parsed = employeeFormSchema.safeParse({ ...completeProfile, categoryAssignedAt: "2026-02-30" });
    expect(parsed.success).toBe(false);
    if (!parsed.success) expect(parsed.error.issues.map(issue => issue.path[0])).toContain("categoryAssignedAt");
  });

  it("requires science field and diploma details when an academic degree is selected", () => {
    const parsed = employeeFormSchema.safeParse({
      ...completeProfile,
      qualificationCategory: "none",
      categoryAssignedAt: "",
      categoryOrderNumber: "",
      academicDegree: "candidate",
      degreeField: "",
      degreeDiploma: "",
    });
    expect(parsed.success).toBe(false);
    if (!parsed.success) {
      const fields = parsed.error.issues.map(issue => issue.path[0]);
      expect(fields).toContain("degreeField");
      expect(fields).toContain("degreeDiploma");
    }
  });

  it("rejects courses shorter than 24 hours and accepts the 24-hour boundary", () => {
    const tooShort = employeeFormSchema.safeParse({
      ...emptyEmployeeForm(),
      courses: [{ monthYear: "апрель, 2025", courseName: "Курс", hours: 23 }],
    });
    expect(tooShort.success).toBe(false);

    const boundary = employeeFormSchema.safeParse({
      ...emptyEmployeeForm(),
      courses: [{ monthYear: "апрель, 2025", courseName: "Курс", hours: 24 }],
    });
    expect(boundary.success).toBe(true);
  });

  it("accepts the month-name format and rejects numeric or out-of-range periods", () => {
    const accepted = employeeFormSchema.safeParse({
      ...emptyEmployeeForm(),
      courses: [{ monthYear: "июль, 2026", courseName: "Курс", hours: 24 }],
    });
    expect(accepted.success).toBe(true);
    expect(employeeFormSchema.safeParse({ ...emptyEmployeeForm(), courses: [{ monthYear: "2025-04", courseName: "Курс", hours: 24 }] }).success).toBe(false);
    expect(employeeFormSchema.safeParse({ ...emptyEmployeeForm(), courses: [{ monthYear: "июль, 2023", courseName: "Курс", hours: 24 }] }).success).toBe(false);
  });
});
