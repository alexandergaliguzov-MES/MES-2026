import { describe, expect, it } from "vitest";
import type { EmployeeRecord } from "../shared/employees";
import { createEmployeeDocx, createEmployeePdf, exportFileName } from "./employeeExport";

const employee: EmployeeRecord = {
  id: 17,
  surname: "Иванова",
  firstName: "Мария",
  middleName: "Сергеевна",
  programs: ["NOO", "SOO"],
  position: "Учитель",
  subjects: "Русский язык, литература",
  education: "higher",
  qualificationCategory: "highest",
  categoryAssignedAt: "2026-09-01",
  categoryOrderNumber: "125-к",
  academicDegree: "candidate",
  degreeField: "Педагогические науки",
  degreeDiploma: "ДК № 123456",
  academicTitle: "associate_professor",
  stateAwards: "Почётный работник сферы образования РФ",
  sportsAwards: "Не указано",
  courses: [{ monthYear: "июль, 2026", courseName: "Современные образовательные практики", hours: 36 }],
  status: "complete",
  createdAt: new Date("2026-01-01T00:00:00Z"),
  updatedAt: new Date("2026-09-01T00:00:00Z"),
};

describe("employee card export", () => {
  it("creates a valid DOCX archive and a Cyrillic-capable PDF for a card", async () => {
    const docx = await createEmployeeDocx([employee]);
    const pdf = await createEmployeePdf([employee]);

    expect(docx.subarray(0, 2).toString()).toBe("PK");
    expect(pdf.subarray(0, 5).toString()).toBe("%PDF-");
    expect(pdf.length).toBeGreaterThan(1000);
  });

  it("uses different filenames for one card and an employee group", () => {
    expect(exportFileName("docx", [employee])).toBe("employee_card_17.docx");
    expect(exportFileName("pdf", [employee, { ...employee, id: 18 }])).toBe("employee_cards_2.pdf");
  });
});
