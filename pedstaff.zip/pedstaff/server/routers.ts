import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { employeeFormSchema } from "../shared/employees";
import { COOKIE_NAME } from "@shared/const";
import {
  createDashboardSession,
  dashboardAttemptKey,
  DASHBOARD_SESSION_COOKIE,
  dashboardClearCookieOptions,
  dashboardCookieOptions,
  isDashboardAuthenticated,
} from "./_core/dashboardAuth";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { dashboardProcedure, publicProcedure, router } from "./_core/trpc";
import {
  clearDashboardLoginFailures,
  createEmployee,
  getDashboardLoginLock,
  getEmployeeById,
  listEmployees,
  recordDashboardLoginFailure,
  updateEmployee,
} from "./db";

function loginLockError(retryAfterSeconds: number) {
  return new TRPCError({
    code: "TOO_MANY_REQUESTS",
    message: `Слишком много попыток. Повторите вход через ${Math.max(1, Math.ceil(retryAfterSeconds / 60))} мин.`,
  });
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  dashboard: router({
    status: publicProcedure.query(({ ctx }) => ({ authenticated: isDashboardAuthenticated(ctx.req) })),
    login: publicProcedure
      .input(z.object({ password: z.string().min(1).max(512) }))
      .mutation(async ({ ctx, input }) => {
        const attemptKey = dashboardAttemptKey(ctx.req);
        const retryAfterSeconds = await getDashboardLoginLock(attemptKey);
        if (retryAfterSeconds) throw loginLockError(retryAfterSeconds);

        const result = createDashboardSession(input.password);
        if (!result.ok) {
          const nextLock = await recordDashboardLoginFailure(attemptKey);
          if (nextLock) throw loginLockError(nextLock);
          throw new TRPCError({ code: "UNAUTHORIZED", message: "Пароль не подошёл. Проверьте введённое значение." });
        }

        await clearDashboardLoginFailures(attemptKey);
        ctx.res.cookie(DASHBOARD_SESSION_COOKIE, result.token, dashboardCookieOptions(ctx.req));
        return { authenticated: true } as const;
      }),
    logout: publicProcedure.mutation(({ ctx }) => {
      ctx.res.clearCookie(DASHBOARD_SESSION_COOKIE, dashboardClearCookieOptions(ctx.req));
      return { success: true } as const;
    }),
  }),
  employees: router({
    list: dashboardProcedure.query(() => listEmployees()),
    get: dashboardProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .query(({ input }) => getEmployeeById(input.id)),
    create: publicProcedure
      .input(employeeFormSchema)
      .mutation(async ({ input }) => {
        const created = await createEmployee(input);
        return { accepted: Boolean(created?.id) };
      }),
    update: dashboardProcedure
      .input(z.object({ id: z.number().int().positive(), employee: employeeFormSchema }))
      .mutation(({ input }) => updateEmployee(input.id, input.employee)),
  }),
});

export type AppRouter = typeof appRouter;
