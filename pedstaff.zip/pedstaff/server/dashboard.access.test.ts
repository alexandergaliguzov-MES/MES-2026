import type { Request, Response } from "express";
import { afterEach, describe, expect, it } from "vitest";
import { emptyEmployeeForm } from "../shared/employees";
import { appRouter } from "./routers";
import {
  createDashboardSession,
  DASHBOARD_SESSION_COOKIE,
  isDashboardAuthenticated,
} from "./_core/dashboardAuth";

const originalPassword = process.env.ADMIN_DASHBOARD_PASSWORD;

function requestWithCookie(cookie?: string, ip = "198.51.100.10") {
  return {
    headers: cookie ? { cookie } : {},
    ip,
    socket: { remoteAddress: ip },
  } as unknown as Request;
}

function callerFor(request: Request) {
  return appRouter.createCaller({ req: request, res: {} as Response, user: null });
}

afterEach(() => {
  if (originalPassword === undefined) delete process.env.ADMIN_DASHBOARD_PASSWORD;
  else process.env.ADMIN_DASHBOARD_PASSWORD = originalPassword;
});

describe("dashboard password access", () => {
  it("issues a signed session only after the configured password is supplied", () => {
    process.env.ADMIN_DASHBOARD_PASSWORD = "test-password";
    expect(createDashboardSession("incorrect").ok).toBe(false);
    const session = createDashboardSession("test-password");
    expect(session.ok).toBe(true);
    if (session.ok) {
      const authenticatedRequest = requestWithCookie(`${DASHBOARD_SESSION_COOKIE}=${encodeURIComponent(session.token)}`, "198.51.100.11");
      expect(isDashboardAuthenticated(authenticatedRequest)).toBe(true);
    }
  });

  it("does not accept a tampered or malformed dashboard session", () => {
    process.env.ADMIN_DASHBOARD_PASSWORD = "test-password";
    const session = createDashboardSession("test-password");
    expect(session.ok).toBe(true);
    if (session.ok) {
      const tampered = `${session.token.slice(0, -1)}x`;
      expect(isDashboardAuthenticated(requestWithCookie(`${DASHBOARD_SESSION_COOKIE}=${encodeURIComponent(tampered)}`, "198.51.100.12"))).toBe(false);
    }
    expect(() => isDashboardAuthenticated(requestWithCookie(`${DASHBOARD_SESSION_COOKIE}=%E0%A4`, "198.51.100.12"))).not.toThrow();
    expect(isDashboardAuthenticated(requestWithCookie(`${DASHBOARD_SESSION_COOKIE}=%E0%A4`, "198.51.100.12"))).toBe(false);
  });

  it("rejects direct list and update requests before reaching the database", async () => {
    const caller = callerFor(requestWithCookie(undefined, "198.51.100.13"));
    await expect(caller.employees.list()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(caller.employees.update({ id: 1, employee: emptyEmployeeForm() })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
});
