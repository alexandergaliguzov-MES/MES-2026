import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import type { CookieOptions, Request } from "express";
import { getSessionCookieOptions } from "./cookies";

export const DASHBOARD_SESSION_COOKIE = "pedstaff_admin_session";
const SESSION_DURATION_MS = 8 * 60 * 60 * 1000;

type SessionPayload = {
  expiresAt: number;
  scope: "pedstaff-dashboard";
  nonce: string;
};

function getConfiguredPassword() {
  return process.env.ADMIN_DASHBOARD_PASSWORD;
}

function equalSecret(left: string, right: string) {
  const leftValue = Buffer.from(left, "utf8");
  const rightValue = Buffer.from(right, "utf8");
  return leftValue.length === rightValue.length && timingSafeEqual(leftValue, rightValue);
}

function sign(payload: string, password: string) {
  return createHmac("sha256", password).update(payload).digest("base64url");
}

function readCookie(req: Request, name: string) {
  const source = req.headers.cookie;
  if (!source) return null;
  for (const part of source.split(";")) {
    const separator = part.indexOf("=");
    if (separator < 0) continue;
    const key = part.slice(0, separator).trim();
    if (key !== name) continue;
    try {
      return decodeURIComponent(part.slice(separator + 1).trim());
    } catch {
      return null;
    }
  }
  return null;
}

function sessionPayload(token: string, password: string): SessionPayload | null {
  const [encoded, signature, ...extra] = token.split(".");
  if (!encoded || !signature || extra.length > 0 || !equalSecret(signature, sign(encoded, password))) return null;

  try {
    const payload = JSON.parse(Buffer.from(encoded, "base64url").toString("utf8")) as SessionPayload;
    if (payload.scope !== "pedstaff-dashboard" || !Number.isFinite(payload.expiresAt) || payload.expiresAt <= Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

export function dashboardCookieOptions(req: Request): CookieOptions {
  return { ...getSessionCookieOptions(req), maxAge: SESSION_DURATION_MS };
}

export function dashboardClearCookieOptions(req: Request): CookieOptions {
  return { ...getSessionCookieOptions(req), maxAge: -1 };
}

export function isDashboardAuthenticated(req: Request) {
  const password = getConfiguredPassword();
  const token = readCookie(req, DASHBOARD_SESSION_COOKIE);
  return Boolean(password && token && sessionPayload(token, password));
}

/** Returns a one-way key for rate limiting without persisting an IP address or a password. */
export function dashboardAttemptKey(req: Request) {
  const password = getConfiguredPassword() ?? "dashboard-password-not-configured";
  const source = req.ip || req.socket.remoteAddress || "unknown";
  return createHmac("sha256", password).update(source).digest("hex");
}

export type DashboardLoginResult =
  | { ok: true; token: string }
  | { ok: false };

export function createDashboardSession(submittedPassword: string): DashboardLoginResult {
  const password = getConfiguredPassword();
  if (!password || !equalSecret(submittedPassword, password)) return { ok: false };

  const encoded = Buffer.from(JSON.stringify({
    expiresAt: Date.now() + SESSION_DURATION_MS,
    scope: "pedstaff-dashboard",
    nonce: randomBytes(18).toString("base64url"),
  } satisfies SessionPayload)).toString("base64url");
  return { ok: true, token: `${encoded}.${sign(encoded, password)}` };
}
