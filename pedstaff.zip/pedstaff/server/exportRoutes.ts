import type { Express, Request, Response } from "express";
import { isDashboardAuthenticated } from "./_core/dashboardAuth";
import { getEmployeesByIds } from "./db";
import { createEmployeeDocx, createEmployeePdf, exportFileName, type EmployeeExportFormat } from "./employeeExport";

const MAX_EXPORT_RECORDS = 100;

function parseIds(value: unknown) {
  if (typeof value !== "string") return null;
  const ids = value.split(",").map(item => Number(item)).filter(id => Number.isInteger(id) && id > 0);
  const uniqueIds = [...new Set(ids)];
  return uniqueIds.length > 0 && uniqueIds.length <= MAX_EXPORT_RECORDS ? uniqueIds : null;
}

function unsupported(res: Response, message: string) {
  return res.status(400).json({ error: message });
}

export function registerEmployeeExportRoutes(app: Express) {
  app.get("/api/exports/:format", async (req: Request, res: Response) => {
    if (!isDashboardAuthenticated(req)) {
      return res.status(401).json({ error: "Для экспорта карточек требуется подтверждённый доступ." });
    }

    const format = req.params.format;
    if (format !== "docx" && format !== "pdf") return unsupported(res, "Поддерживаются только форматы DOCX и PDF.");
    const ids = parseIds(req.query.ids);
    if (!ids) return unsupported(res, `Выберите от 1 до ${MAX_EXPORT_RECORDS} сотрудников для экспорта.`);

    try {
      const employees = await getEmployeesByIds(ids);
      if (employees.length !== ids.length) return res.status(404).json({ error: "Не все выбранные карточки найдены." });

      const file = format === "docx" ? await createEmployeeDocx(employees) : await createEmployeePdf(employees);
      const contentType = format === "docx"
        ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        : "application/pdf";
      res.set({
        "Cache-Control": "private, no-store",
        "Content-Type": contentType,
        "Content-Disposition": `attachment; filename="${exportFileName(format as EmployeeExportFormat, employees)}"`,
        "X-Content-Type-Options": "nosniff",
      });
      return res.send(file);
    } catch (error) {
      console.error("[Employee export] Failed to create document:", error instanceof Error ? error.message : error);
      return res.status(500).json({ error: "Не удалось подготовить экспорт. Повторите попытку." });
    }
  });
}
