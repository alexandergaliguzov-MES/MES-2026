import { desc, eq, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import type { EmployeeFormData, EmployeeRecord } from "../shared/employees";
import { dashboardLoginAttempts, type Employee, type InsertEmployee, type InsertUser, employees, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the Drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

const MAX_DASHBOARD_LOGIN_FAILURES = 8;
const DASHBOARD_LOGIN_LOCK_MS = 15 * 60 * 1000;

export async function getDashboardLoginLock(attemptKey: string): Promise<number | null> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const [attempt] = await db.select().from(dashboardLoginAttempts).where(eq(dashboardLoginAttempts.attemptKey, attemptKey)).limit(1);
  if (!attempt?.lockedUntil) return null;
  const remaining = attempt.lockedUntil.getTime() - Date.now();
  return remaining > 0 ? Math.ceil(remaining / 1000) : null;
}

export async function recordDashboardLoginFailure(attemptKey: string): Promise<number | null> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const [existing] = await db.select().from(dashboardLoginAttempts).where(eq(dashboardLoginAttempts.attemptKey, attemptKey)).limit(1);
  const lockExpired = Boolean(existing?.lockedUntil && existing.lockedUntil.getTime() <= Date.now());
  const failures = (lockExpired ? 0 : existing?.failures ?? 0) + 1;
  const lockedUntil = failures >= MAX_DASHBOARD_LOGIN_FAILURES ? new Date(Date.now() + DASHBOARD_LOGIN_LOCK_MS) : null;
  const values = { failures, lockedUntil, updatedAt: new Date() };

  if (existing) {
    await db.update(dashboardLoginAttempts).set(values).where(eq(dashboardLoginAttempts.attemptKey, attemptKey));
  } else {
    await db.insert(dashboardLoginAttempts).values({ attemptKey, ...values });
  }
  return lockedUntil ? Math.ceil(DASHBOARD_LOGIN_LOCK_MS / 1000) : null;
}

export async function clearDashboardLoginFailures(attemptKey: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(dashboardLoginAttempts).where(eq(dashboardLoginAttempts.attemptKey, attemptKey));
}

function toEmployeeRow(input: EmployeeFormData): InsertEmployee {
  return {
    surname: input.surname.trim(),
    firstName: input.firstName.trim(),
    middleName: input.middleName.trim(),
    programs: input.programs,
    position: input.position.trim(),
    subjects: input.subjects.trim(),
    education: input.education,
    qualificationCategory: input.qualificationCategory,
    categoryAssignedAt: input.categoryAssignedAt || null,
    categoryOrderNumber: input.categoryOrderNumber.trim() || null,
    academicDegree: input.academicDegree,
    degreeField: input.degreeField.trim() || null,
    degreeDiploma: input.degreeDiploma.trim() || null,
    academicTitle: input.academicTitle,
    stateAwards: input.stateAwards.trim() || null,
    sportsAwards: input.sportsAwards.trim() || null,
    courses: input.courses,
    status: input.status,
  };
}

function normalizeEmployee(row: Employee): EmployeeRecord {
  return {
    ...row,
    programs: row.programs ?? [],
    categoryAssignedAt: row.categoryAssignedAt ?? "",
    categoryOrderNumber: row.categoryOrderNumber ?? "",
    degreeField: row.degreeField ?? "",
    degreeDiploma: row.degreeDiploma ?? "",
    stateAwards: row.stateAwards ?? "",
    sportsAwards: row.sportsAwards ?? "",
    courses: row.courses ?? [],
  } as EmployeeRecord;
}

export async function listEmployees(): Promise<EmployeeRecord[]> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const rows = await db.select().from(employees).orderBy(desc(employees.updatedAt));
  return rows.map(normalizeEmployee);
}

export async function getEmployeeById(id: number): Promise<EmployeeRecord | null> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.select().from(employees).where(eq(employees.id, id)).limit(1);
  return result[0] ? normalizeEmployee(result[0]) : null;
}

export async function getEmployeesByIds(ids: number[]): Promise<EmployeeRecord[]> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const uniqueIds = [...new Set(ids)];
  if (!uniqueIds.length) return [];
  const rows = await db.select().from(employees).where(inArray(employees.id, uniqueIds));
  const byId = new Map(rows.map(row => [row.id, normalizeEmployee(row)]));
  return uniqueIds.flatMap(id => {
    const employee = byId.get(id);
    return employee ? [employee] : [];
  });
}

export async function createEmployee(input: EmployeeFormData): Promise<EmployeeRecord | null> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const [created] = await db.insert(employees).values(toEmployeeRow(input)).$returningId();
  if (!created) throw new Error("Could not create employee record");
  return getEmployeeById(Number(created.id));
}

export async function updateEmployee(id: number, input: EmployeeFormData): Promise<EmployeeRecord | null> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(employees).set(toEmployeeRow(input)).where(eq(employees.id, id));
  return getEmployeeById(id);
}
