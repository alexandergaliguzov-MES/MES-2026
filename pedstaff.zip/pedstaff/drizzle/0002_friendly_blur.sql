CREATE TABLE `dashboard_login_attempts` (
	`attemptKey` varchar(64) NOT NULL,
	`failures` int NOT NULL DEFAULT 0,
	`lockedUntil` timestamp,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `dashboard_login_attempts_attemptKey` PRIMARY KEY(`attemptKey`)
);
