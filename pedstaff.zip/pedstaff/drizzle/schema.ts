import { int, json, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";
import type { EmployeeFormData } from "../shared/employees";

/** Core user table backing the starter authentication flow. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/** Hashed browser-network keys only; no raw IP addresses or password values are stored. */
export const dashboardLoginAttempts = mysqlTable("dashboard_login_attempts", {
  attemptKey: varchar("attemptKey", { length: 64 }).primaryKey(),
  failures: int("failures").default(0).notNull(),
  lockedUntil: timestamp("lockedUntil"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Publicly accessible staff profile; programs and course rows remain attached to one record. */
export const employees = mysqlTable("employees", {
  id: int("id").autoincrement().primaryKey(),
  surname: varchar("surname", { length: 120 }).notNull(),
  firstName: varchar("firstName", { length: 120 }).notNull(),
  middleName: varchar("middleName", { length: 120 }).notNull(),
  programs: json("programs").$type<EmployeeFormData["programs"]>().notNull(),
  position: varchar("position", { length: 180 }).notNull(),
  subjects: varchar("subjects", { length: 500 }).notNull(),
  education: mysqlEnum("education", ["higher", "secondary_special", "none"]),
  qualificationCategory: mysqlEnum("qualificationCategory", ["first", "highest", "none"]),
  categoryAssignedAt: varchar("categoryAssignedAt", { length: 10 }),
  categoryOrderNumber: varchar("categoryOrderNumber", { length: 120 }),
  academicDegree: mysqlEnum("academicDegree", ["candidate", "doctor"]),
  degreeField: varchar("degreeField", { length: 180 }),
  degreeDiploma: varchar("degreeDiploma", { length: 180 }),
  academicTitle: mysqlEnum("academicTitle", ["associate_professor", "professor"]),
  stateAwards: text("stateAwards"),
  sportsAwards: text("sportsAwards"),
  courses: json("courses").$type<EmployeeFormData["courses"]>().notNull(),
  status: mysqlEnum("status", ["draft", "complete"]).default("draft").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Employee = typeof employees.$inferSelect;
export type InsertEmployee = typeof employees.$inferInsert;
