import { useMemo, useState } from "react";
import {
  ArrowLeft, ArrowUpRight, Award, BadgeCheck, BookOpen, CheckCircle2, ChevronRight,
  ClipboardList, FileCheck2, FileText, GraduationCap, KeyRound, LockKeyhole, LogIn,
  LogOut, Plus, Search, Send, ShieldCheck, UsersRound,
} from "lucide-react";
import EmployeeForm from "@/components/staff/EmployeeForm";
import EmployeeDirectory from "@/components/staff/EmployeeDirectory";
import EmployeeExportButtons from "@/components/staff/EmployeeExportButtons";
import { trpc } from "@/lib/trpc";
import {
  completionPercent, emptyEmployeeForm, employeeFormSchema, formatCoursePeriod, programLabels,
  type EmployeeFormData, type EmployeeRecord, type EmployeeStatus,
} from "@shared/employees";

const LOGO_URL = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663528420277/bjiAoRMfxmtbZcPL.png";
type ProgramCode = keyof typeof programLabels;
type Page = "publicForm" | "submitted" | "adminLogin" | "overview" | "directory" | "form" | "profile";

function fullName(employee: Pick<EmployeeFormData, "surname" | "firstName" | "middleName">) {
  return [employee.surname, employee.firstName, employee.middleName].filter(Boolean).join(" ") || "Сотрудник";
}
function initials(employee: EmployeeRecord) {
  return `${employee.surname.trim().charAt(0)}${employee.firstName.trim().charAt(0)}`.toLocaleUpperCase("ru") || "П";
}
function humanDate(value: Date | string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "—" : new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "short", year: "numeric" }).format(date);
}
const educationLabels: Record<NonNullable<EmployeeFormData["education"]>, string> = {
  higher: "Высшее", secondary_special: "Среднее специальное", none: "Без образования",
};
const categoryLabels: Record<NonNullable<EmployeeFormData["qualificationCategory"]>, string> = {
  first: "Первая", highest: "Высшая", none: "Отсутствует",
};
const degreeLabels = { candidate: "Кандидат наук", doctor: "Доктор наук" } as const;
const titleLabels = { associate_professor: "Доцент", professor: "Профессор" } as const;
const schoolLabels: Record<ProgramCode, string> = { NOO: "Начальная школа", OOO: "Основная школа", SOO: "Старшая школа" };

function DetailLine({ label, value }: { label: string; value?: string | number | null }) {
  return <div className="detail-line"><span>{label}</span><strong>{value || "Не указано"}</strong></div>;
}

export default function Home() {
  const [page, setPage] = useState<Page>("publicForm");
  const [filter, setFilter] = useState<ProgramCode | "ALL">("ALL");
  const [search, setSearch] = useState("");
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [draft, setDraft] = useState<EmployeeFormData>(emptyEmployeeForm());
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [serverError, setServerError] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [submittedName, setSubmittedName] = useState("");
  const [selectedExportIds, setSelectedExportIds] = useState<number[]>([]);

  const utils = trpc.useUtils();
  const dashboardStatus = trpc.dashboard.status.useQuery(undefined, { retry: false, refetchOnWindowFocus: true });
  const isAdmin = Boolean(dashboardStatus.data?.authenticated);
  const employeesQuery = trpc.employees.list.useQuery(undefined, { enabled: isAdmin, retry: false });
  const createMutation = trpc.employees.create.useMutation();
  const updateMutation = trpc.employees.update.useMutation();
  const loginMutation = trpc.dashboard.login.useMutation();
  const logoutMutation = trpc.dashboard.logout.useMutation();
  const isSaving = createMutation.isPending || updateMutation.isPending;
  const employees = employeesQuery.data ?? [];
  const isAdminPage = page === "overview" || page === "directory" || page === "form" || page === "profile";
  const activeExportIds = useMemo(() => selectedExportIds.filter(id => employees.some(employee => employee.id === id)), [employees, selectedExportIds]);

  const selectedEmployee = employees.find(employee => employee.id === selectedId) ?? null;
  const filteredEmployees = useMemo(() => {
    const query = search.trim().toLocaleLowerCase("ru");
    return employees.filter(employee => {
      const matchesProgram = filter === "ALL" || employee.programs.includes(filter);
      const matchesSearch = !query || `${fullName(employee)} ${employee.position} ${employee.subjects}`.toLocaleLowerCase("ru").includes(query);
      return matchesProgram && matchesSearch;
    });
  }, [employees, filter, search]);
  const counts = useMemo(() => ({
    complete: employees.filter(employee => employee.status === "complete").length,
    drafts: employees.filter(employee => employee.status === "draft").length,
    average: employees.length ? Math.round(employees.reduce((sum, employee) => sum + completionPercent(employee), 0) / employees.length) : 0,
    byProgram: {
      NOO: employees.filter(employee => employee.programs.includes("NOO")).length,
      OOO: employees.filter(employee => employee.programs.includes("OOO")).length,
      SOO: employees.filter(employee => employee.programs.includes("SOO")).length,
    },
  }), [employees]);

  const toggleExportSelection = (id: number) => {
    setSelectedExportIds(current => current.includes(id) ? current.filter(item => item !== id) : [...current, id]);
  };
  const toggleVisibleExportSelection = () => {
    const visibleIds = filteredEmployees.map(employee => employee.id);
    setSelectedExportIds(current => {
      const allVisibleSelected = visibleIds.every(id => current.includes(id));
      return allVisibleSelected ? current.filter(id => !visibleIds.includes(id)) : [...new Set([...current, ...visibleIds])];
    });
  };
  const resetPublicForm = () => {
    setEditingId(null);
    setDraft(emptyEmployeeForm());
    setFieldErrors({});
    setServerError("");
    setPage("publicForm");
  };
  const beginNew = () => {
    if (!isAdmin) return resetPublicForm();
    setEditingId(null);
    setDraft(emptyEmployeeForm());
    setFieldErrors({});
    setServerError("");
    setPage("form");
  };
  const beginEdit = (employee: EmployeeRecord) => {
    if (!isAdmin) return;
    const { id, createdAt: _createdAt, updatedAt: _updatedAt, ...form } = employee;
    setSelectedId(id);
    setEditingId(id);
    setDraft({ ...emptyEmployeeForm(), ...form, courses: form.courses.map(course => ({ ...course, monthYear: formatCoursePeriod(course.monthYear) })) });
    setFieldErrors({});
    setServerError("");
    setPage("form");
  };
  const save = (status: EmployeeStatus) => {
    if (editingId !== null && !isAdmin) return;
    setServerError("");
    const parsed = employeeFormSchema.safeParse({ ...draft, status, courses: draft.courses.filter(course => course.monthYear || course.courseName.trim() || course.hours !== null) });
    if (!parsed.success) {
      const nextErrors: Record<string, string> = {};
      for (const issue of parsed.error.issues) {
        const key = issue.path.join(".");
        if (key && !nextErrors[key]) nextErrors[key] = issue.message;
      }
      setFieldErrors(nextErrors);
      const firstIssue = parsed.error.issues[0];
      if (firstIssue?.path[0] === "courses") setServerError("Проверьте строки курсов: указываются только курсы за 2024–2026 годы продолжительностью не менее 24 часов.");
      return;
    }
    setFieldErrors({});
    const name = fullName(parsed.data);
    const onAdminSuccess = async (saved: EmployeeRecord | null) => {
      await utils.employees.list.invalidate();
      setServerError("");
      if (saved) {
        setSelectedId(saved.id);
        setPage("profile");
      } else {
        setPage("directory");
      }
    };
    const onPublicSuccess = () => {
      setSubmittedName(name);
      setDraft(emptyEmployeeForm());
      setServerError("");
      setPage("submitted");
    };
    const onError = (error: { message: string }) => setServerError(`Не удалось сохранить анкету: ${error.message}`);
    if (editingId !== null) updateMutation.mutate({ id: editingId, employee: parsed.data }, { onSuccess: onAdminSuccess, onError });
    else if (isAdmin) createMutation.mutate(parsed.data, { onSuccess: async () => { await utils.employees.list.invalidate(); setPage("directory"); }, onError });
    else createMutation.mutate(parsed.data, { onSuccess: onPublicSuccess, onError });
  };
  const goToDirectory = (nextFilter: ProgramCode | "ALL" = "ALL") => {
    if (!isAdmin) return setPage("adminLogin");
    setFilter(nextFilter);
    setPage("directory");
  };
  const openAdmin = () => {
    setLoginError("");
    setPage(isAdmin ? "overview" : "adminLogin");
  };
  const login = (event: React.FormEvent) => {
    event.preventDefault();
    setLoginError("");
    loginMutation.mutate({ password: loginPassword }, {
      onSuccess: () => {
        setLoginPassword("");
        utils.dashboard.status.setData(undefined, { authenticated: true });
        void utils.employees.list.invalidate();
        setPage("overview");
      },
      onError: error => setLoginError(error.message),
    });
  };
  const logout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        utils.dashboard.status.setData(undefined, { authenticated: false });
        utils.employees.list.setData(undefined, []);
        setEditingId(null);
        setSelectedId(null);
        setSelectedExportIds([]);
        resetPublicForm();
      },
    });
  };
  const pageTitle = page === "overview" ? "Обзор" : page === "directory" ? "Сотрудники" : page === "form" ? (editingId ? "Редактирование" : "Новая анкета") : page === "profile" ? "Карточка сотрудника" : page === "adminLogin" ? "Закрытый раздел" : "Заполнение анкеты";

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <button className="brand-block" type="button" onClick={() => isAdmin ? setPage("overview") : resetPublicForm()} aria-label="На главную">
          <img src={LOGO_URL} alt="Московская экономическая школа" />
          <span><strong>Педагогический<br />состав</strong><small>Сведения о сотрудниках</small></span>
        </button>
        {isAdmin ? <>
          <div className="side-label">ЗАКРЫТЫЙ РАЗДЕЛ</div>
          <nav className="side-nav" aria-label="Основная навигация">
            <button className={`nav-item ${page === "overview" ? "active" : ""}`} onClick={() => setPage("overview")}><span className="nav-icon"><ClipboardList size={19} /></span>Обзор</button>
            <button className={`nav-item ${page === "directory" || page === "profile" ? "active" : ""}`} onClick={() => goToDirectory()}><span className="nav-icon"><UsersRound size={19} /></span>Сотрудники<span className="nav-count">{employees.length}</span></button>
          </nav>
          <div className="side-divider" />
          <div className="side-label">ФИЛЬТР ПО ШКОЛЕ</div>
          <nav className="side-nav school-nav" aria-label="Фильтр по уровню школы">
            {(Object.keys(schoolLabels) as ProgramCode[]).map(program => <button className={`nav-item ${filter === program && (page === "directory" || page === "profile") ? "active" : ""}`} key={program} onClick={() => goToDirectory(program)}><span className={`school-bullet ${program.toLowerCase()}`} />{schoolLabels[program]}<span className="nav-count">{counts.byProgram[program]}</span></button>)}
          </nav>
        </> : <>
          <div className="side-label">ОТКРЫТАЯ ФОРМА</div>
          <nav className="side-nav" aria-label="Навигация формы">
            <button className={`nav-item ${page === "publicForm" || page === "submitted" ? "active" : ""}`} onClick={resetPublicForm}><span className="nav-icon"><FileText size={19} /></span>Заполнить анкету</button>
            <button className={`nav-item ${page === "adminLogin" ? "active" : ""}`} onClick={openAdmin}><span className="nav-icon"><LockKeyhole size={19} /></span>Закрытый раздел</button>
          </nav>
        </>}
        <div className="sidebar-bottom">
          {isAdmin ? <><div className="public-mode admin-mode"><ShieldCheck size={19} /><span><strong>Доступ подтверждён</strong><small>Закрытый раздел</small></span></div><button className="text-button sidebar-logout" onClick={logout} disabled={logoutMutation.isPending}><LogOut size={17} />Выйти</button></> : <><div className="public-mode"><ShieldCheck size={19} /><span><strong>Анкета открыта</strong><small>Вход не требуется</small></span></div><p>Сохранённые анкеты, карточки и статистика доступны только утверждённым пользователям.</p></>}
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div className="breadcrumbs"><span>Сведения о педагогах</span><ChevronRight size={16} /><strong>{pageTitle}</strong></div>
          <div className="top-actions">
            {isAdmin ? <><span className="sync-state"><span className="sync-dot" />Защищённый доступ</span><button className="button button-primary top-add" type="button" onClick={beginNew}><Plus size={19} />Добавить сотрудника</button></> : <button className="button button-outline top-add" type="button" onClick={openAdmin}><KeyRound size={18} />Для утверждённых</button>}
          </div>
        </header>

        {page === "publicForm" && <EmployeeForm value={draft} errors={fieldErrors} saving={createMutation.isPending} serverError={serverError} editing={false} publicMode onChange={next => { setDraft(next); setFieldErrors({}); setServerError(""); }} onSave={save} onCancel={resetPublicForm} />}

        {page === "submitted" && <section className="page-content public-result-page"><div className="public-result-card panel"><span className="public-result-icon"><CheckCircle2 size={34} /></span><p className="eyebrow">АНКЕТА ПРИНЯТА</p><h1>Спасибо{submittedName ? `, ${submittedName}` : ""}!</h1><p>Сведения отправлены и доступны для проверки только утверждённым пользователям в закрытом разделе.</p><div className="public-result-actions"><button className="button button-primary" onClick={resetPublicForm}><Plus size={19} />Заполнить ещё одну анкету</button><button className="button button-outline" onClick={openAdmin}><LockKeyhole size={18} />Закрытый раздел</button></div></div></section>}

        {(page === "adminLogin" || (isAdminPage && !isAdmin && !dashboardStatus.isLoading)) && <section className="page-content admin-login-page"><div className="admin-login-card panel"><span className="admin-login-icon"><LockKeyhole size={30} /></span><p className="eyebrow">ДОСТУП ДЛЯ УТВЕРЖДЁННЫХ ПОЛЬЗОВАТЕЛЕЙ</p><h1>Закрытый раздел</h1><p className="page-subtitle">Введите единый пароль, чтобы просматривать сохранённые анкеты, карточки сотрудников и аналитику.</p><form className="login-form" onSubmit={login}><label className="field-label" htmlFor="admin-password">Пароль</label><input id="admin-password" className="control password-control" type="password" value={loginPassword} onChange={event => setLoginPassword(event.target.value)} autoComplete="current-password" placeholder="Введите пароль" disabled={loginMutation.isPending} required />{loginError && <div className="login-error" role="alert">{loginError}</div>}<button className="button button-primary login-submit" type="submit" disabled={loginMutation.isPending}>{loginMutation.isPending ? "Проверяем…" : <><LogIn size={19} />Открыть закрытый раздел</>}</button></form><div className="access-note"><ShieldCheck size={18} /><span>Открытая ссылка предназначена только для отправки новых анкет. Сохранённые данные не показываются без пароля.</span></div><button className="text-button return-to-form" onClick={resetPublicForm}><ArrowLeft size={17} />Вернуться к заполнению анкеты</button></div></section>}

        {isAdmin && page === "overview" && <section className="page-content overview-page">
          <div className="page-heading-row"><div><p className="eyebrow">ЗАЩИЩЁННОЕ УПРАВЛЕНИЕ КАДРОВЫМИ СВЕДЕНИЯМИ</p><h1>Педагогический состав</h1><p className="page-subtitle">Сведения о сотрудниках и готовность анкет к проверке</p></div><button className="button button-outline" type="button" onClick={() => goToDirectory()}><UsersRound size={19} />Открыть список</button></div>
          <div className="alert alert-private"><LockKeyhole size={21} /><div><strong>Сохранённые анкеты защищены</strong><span>Просмотр, поиск и редактирование доступны только после входа с утверждённым паролем.</span></div><span className="alert-tag">ЗАКРЫТЫЙ РАЗДЕЛ</span></div>
          {employeesQuery.isError && <div className="alert alert-error">Не удалось загрузить данные. Проверьте соединение с базой данных и обновите страницу.</div>}
          <div className="stat-grid">
            <button className="stat-card stat-card-primary" onClick={() => goToDirectory()}><span className="stat-icon"><UsersRound size={21} /></span><span className="stat-label">Всего сотрудников</span><strong className="stat-number">{employeesQuery.isLoading ? "—" : employees.length}</strong><span className="stat-foot">Сохранённые карточки <ArrowUpRight size={16} /></span></button>
            <button className="stat-card" onClick={() => goToDirectory()}><span className="stat-icon stat-icon-green"><FileCheck2 size={21} /></span><span className="stat-label">Анкеты заполнены</span><strong className="stat-number">{employeesQuery.isLoading ? "—" : counts.complete}</strong><span className="stat-foot">Завершённых анкет</span></button>
            <button className="stat-card" onClick={() => goToDirectory()}><span className="stat-icon stat-icon-gold"><ClipboardList size={21} /></span><span className="stat-label">Среднее заполнение</span><strong className="stat-number">{employeesQuery.isLoading ? "—" : `${counts.average}%`}</strong><span className="stat-foot">Черновиков: {counts.drafts}</span></button>
          </div>
          <div className="dashboard-grid">
            <section className="panel school-panel"><div className="panel-header"><div><p className="eyebrow">РАСПРЕДЕЛЕНИЕ</p><h2>По уровням школы</h2></div><button className="text-button" onClick={() => goToDirectory()}>Все сотрудники <ArrowUpRight size={16} /></button></div><div className="school-stats">{(Object.keys(schoolLabels) as ProgramCode[]).map((program, index) => <button className="school-stat" key={program} onClick={() => goToDirectory(program)}><span className={`school-stat-mark mark-${index + 1}`}>{programLabels[program]}</span><span className="school-stat-copy"><strong>{schoolLabels[program]}</strong><small>{counts.byProgram[program]} {counts.byProgram[program] === 1 ? "сотрудник" : "сотрудников"}</small></span><span className="school-stat-arrow"><ChevronRight size={19} /></span><span className="mini-bar"><i style={{ width: `${employees.length ? Math.max(4, counts.byProgram[program] / employees.length * 100) : 0}%` }} /></span></button>)}</div><p className="panel-footnote">Сотрудники, работающие на нескольких уровнях, учитываются в каждом соответствующем разделе.</p></section>
            <section className="panel completion-panel"><div className="panel-header"><div><p className="eyebrow">КАЧЕСТВО ДАННЫХ</p><h2>Заполнение анкет</h2></div><span className="round-icon"><BadgeCheck size={21} /></span></div><div className="completion-summary"><strong>{counts.average}%</strong><span>средняя полнота<br />данных по карточкам</span></div><div className="progress-track"><span style={{ width: `${counts.average}%` }} /></div><div className="completion-legend"><span><i className="legend-dot complete-dot" />Завершено <strong>{counts.complete}</strong></span><span><i className="legend-dot draft-dot" />Черновик <strong>{counts.drafts}</strong></span></div><button className="completion-link" onClick={() => goToDirectory()}>Проверить анкеты <ChevronRight size={18} /></button></section>
          </div>
          <section className="panel recent-panel"><div className="panel-header"><div><p className="eyebrow">ПОСЛЕДНИЕ ИЗМЕНЕНИЯ</p><h2>Недавно обновлённые карточки</h2></div><button className="text-button" onClick={() => goToDirectory()}>Весь список <ArrowUpRight size={16} /></button></div>{employeesQuery.isLoading ? <div className="empty-state compact">Загружаем данные…</div> : employees.length ? <div className="recent-list">{employees.slice(0, 5).map(employee => <button className="recent-row" key={employee.id} onClick={() => { setSelectedId(employee.id); setPage("profile"); }}><span className="avatar small-avatar">{initials(employee)}</span><span className="recent-name"><strong>{fullName(employee)}</strong><small>{employee.position || "Должность не указана"}</small></span><span className="recent-programs">{employee.programs.map(code => <i key={code}>{programLabels[code]}</i>)}</span><span className={`status-badge ${employee.status}`}>{employee.status === "complete" ? "Заполнена" : "Черновик"}</span><span className="recent-percent">{completionPercent(employee)}%</span><ChevronRight size={18} className="muted-icon" /></button>)}</div> : <div className="empty-state"><span className="empty-icon"><UsersRound size={24} /></span><strong>Карточек пока нет</strong><span>Открытая форма уже доступна для сотрудников. После отправки анкеты появятся в этом закрытом разделе.</span><button className="button button-primary" onClick={beginNew}><Plus size={18} />Добавить сотрудника</button></div>}</section>
        </section>}

        {isAdmin && page === "directory" && <EmployeeDirectory
          employees={employees}
          filteredEmployees={filteredEmployees}
          filter={filter}
          search={search}
          loading={employeesQuery.isLoading}
          selectedIds={activeExportIds}
          byProgram={counts.byProgram}
          onFilterChange={nextFilter => setFilter(nextFilter)}
          onSearchChange={setSearch}
          onNew={beginNew}
          onOpen={id => { setSelectedId(id); setPage("profile"); }}
          onToggle={toggleExportSelection}
          onToggleVisible={toggleVisibleExportSelection}
        />}


        {isAdmin && page === "form" && <EmployeeForm value={draft} errors={fieldErrors} saving={isSaving} serverError={serverError} editing={editingId !== null} onChange={next => { setDraft(next); setFieldErrors({}); setServerError(""); }} onSave={save} onCancel={() => { setServerError(""); setPage(editingId === null ? "directory" : "profile"); }} />}

        {isAdmin && page === "profile" && <section className="page-content profile-page">{!selectedEmployee ? <div className="panel empty-state"><span className="empty-icon"><UsersRound size={23} /></span><strong>Карточка не найдена</strong><span>Возможно, список ещё загружается или запись больше недоступна.</span><button className="button button-outline" onClick={() => setPage("directory")}><ArrowLeft size={18} />К списку</button></div> : <><button className="back-link" onClick={() => setPage("directory")}><ArrowLeft size={19} />К списку сотрудников</button><div className="profile-hero panel"><span className="avatar profile-avatar">{initials(selectedEmployee)}</span><div className="profile-identity"><p className="eyebrow">КАРТОЧКА СОТРУДНИКА · № {selectedEmployee.id}</p><h1>{fullName(selectedEmployee)}</h1><span>{selectedEmployee.position || "Должность не указана"}</span><div className="tag-row">{selectedEmployee.programs.map(code => <span className="program-tag" key={code}>{programLabels[code]} · {schoolLabels[code as ProgramCode]}</span>)}</div></div><div className="profile-actions"><span className={`status-badge ${selectedEmployee.status}`}>{selectedEmployee.status === "complete" ? "Заполнена" : "Черновик"}</span><div className="profile-export-actions"><EmployeeExportButtons employeeIds={[selectedEmployee.id]} compact /><button className="button button-primary" onClick={() => beginEdit(selectedEmployee)}><FileText size={18} />Редактировать</button></div></div></div><div className="profile-progress panel"><div><span className="eyebrow">ПОЛНОТА ДАННЫХ</span><strong>{completionPercent(selectedEmployee)}%</strong></div><div className="progress-track"><span style={{ width: `${completionPercent(selectedEmployee)}%` }} /></div><span className="profile-updated">Обновлено {humanDate(selectedEmployee.updatedAt)}</span></div><div className="profile-grid"><section className="panel detail-panel"><div className="panel-header"><div className="detail-heading-icon"><BookOpen size={19} /><h2>Общие сведения</h2></div></div><DetailLine label="Фамилия" value={selectedEmployee.surname} /><DetailLine label="Имя" value={selectedEmployee.firstName} /><DetailLine label="Отчество" value={selectedEmployee.middleName} /><DetailLine label="Должность" value={selectedEmployee.position} /><DetailLine label="Предметы, курсы, модули" value={selectedEmployee.subjects} /><DetailLine label="Образовательные программы" value={selectedEmployee.programs.map(code => `${programLabels[code]} (${schoolLabels[code as ProgramCode]})`).join(", ")} /></section><section className="panel detail-panel"><div className="panel-header"><div className="detail-heading-icon"><GraduationCap size={20} /><h2>Квалификация</h2></div></div><DetailLine label="Уровень образования" value={selectedEmployee.education ? educationLabels[selectedEmployee.education] : ""} /><DetailLine label="Квалификационная категория" value={selectedEmployee.qualificationCategory ? categoryLabels[selectedEmployee.qualificationCategory] : ""} />{selectedEmployee.qualificationCategory && ["first", "highest"].includes(selectedEmployee.qualificationCategory) && <><DetailLine label="Дата присвоения" value={selectedEmployee.categoryAssignedAt} /><DetailLine label="Номер приказа" value={selectedEmployee.categoryOrderNumber} /></>}<DetailLine label="Учёная степень" value={selectedEmployee.academicDegree ? degreeLabels[selectedEmployee.academicDegree] : ""} />{selectedEmployee.academicDegree && <><DetailLine label="Отрасль науки" value={selectedEmployee.degreeField} /><DetailLine label="Диплом" value={selectedEmployee.degreeDiploma} /></>}<DetailLine label="Учёное звание" value={selectedEmployee.academicTitle ? titleLabels[selectedEmployee.academicTitle] : ""} /></section><section className="panel detail-panel"><div className="panel-header"><div className="detail-heading-icon"><Award size={19} /><h2>Награды и достижения</h2></div></div><DetailLine label="Государственные и ведомственные награды" value={selectedEmployee.stateAwards} /><DetailLine label="Спортивные звания и награды" value={selectedEmployee.sportsAwards} /></section><section className="panel detail-panel courses-detail"><div className="panel-header"><div className="detail-heading-icon"><FileCheck2 size={19} /><h2>Повышение квалификации</h2></div><span className="course-count">{selectedEmployee.courses.length} {selectedEmployee.courses.length === 1 ? "курс" : "курсов"}</span></div>{selectedEmployee.courses.length ? <div className="profile-course-list">{selectedEmployee.courses.map((course, index) => <div className="profile-course-row" key={index}><span>{course.monthYear ? monthName(course.monthYear) : "—"}</span><strong>{course.courseName || "Название курса не указано"}</strong><span>{course.hours ?? "—"} ч.</span></div>)}</div> : <p className="no-courses">Сведения о курсах не внесены.</p>}<p className="course-rule">Курсы менее 24 часов не указываются.</p></section></div></>}</section>}
        <footer className="app-footer"><span>Московская экономическая школа</span><span>{isAdmin ? "Закрытый раздел сведений о педагогах" : "Открытая форма сбора сведений"}</span></footer>
      </main>
    </div>
  );
}

function monthName(value: string) {
  return formatCoursePeriod(value);
}
