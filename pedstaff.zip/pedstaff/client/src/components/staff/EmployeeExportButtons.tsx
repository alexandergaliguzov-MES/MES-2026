import { Download, FileText } from "lucide-react";

export type EmployeeExportFormat = "docx" | "pdf";

type Props = {
  employeeIds: number[];
  compact?: boolean;
  group?: boolean;
};

function downloadExport(format: EmployeeExportFormat, employeeIds: number[]) {
  if (!employeeIds.length) return;
  const search = new URLSearchParams({ ids: employeeIds.join(",") });
  window.location.assign(`/api/exports/${format}?${search.toString()}`);
}

export default function EmployeeExportButtons({ employeeIds, compact = false, group = false }: Props) {
  const disabled = employeeIds.length === 0;
  const target = group ? `выбранных сотрудников (${employeeIds.length})` : "карточки сотрудника";

  return (
    <div className={`export-actions ${compact ? "compact" : ""}`} aria-label={`Экспорт ${target}`}>
      <button className="button button-outline export-button" type="button" disabled={disabled} onClick={() => downloadExport("docx", employeeIds)} title={`Скачать ${target} в DOCX`}>
        <FileText size={compact ? 16 : 18} /> DOCX
      </button>
      <button className="button button-outline export-button" type="button" disabled={disabled} onClick={() => downloadExport("pdf", employeeIds)} title={`Скачать ${target} в PDF`}>
        <Download size={compact ? 16 : 18} /> PDF
      </button>
    </div>
  );
}
