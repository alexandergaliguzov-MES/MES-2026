import { ChevronRight, Download, Plus, Search } from "lucide-react";
import type { EmployeeRecord } from "@shared/employees";
import { completionPercent, programLabels } from "@shared/employees";
import EmployeeExportButtons from "./EmployeeExportButtons";

type ProgramCode = keyof typeof programLabels;
type Props = {
  employees: EmployeeRecord[];
  filteredEmployees: EmployeeRecord[];
  filter: ProgramCode | "ALL";
  search: string;
  loading: boolean;
  selectedIds: number[];
  byProgram: Record<ProgramCode, number>;
  onFilterChange: (filter: ProgramCode | "ALL") => void;
  onSearchChange: (value: string) => void;
  onNew: () => void;
  onOpen: (id: number) => void;
  onToggle: (id: number) => void;
  onToggleVisible: () => void;
};

function fullName(employee: EmployeeRecord) {
  return [employee.surname, employee.firstName, employee.middleName].filter(Boolean).join(" ") || "Сотрудник";
}

function initials(employee: EmployeeRecord) {
  return `${employee.surname.trim().charAt(0)}${employee.firstName.trim().charAt(0)}`.toLocaleUpperCase("ru") || "П";
}

function humanDate(value: Date | string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "—" : new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "short", year: "numeric" }).format(date);
}

export default function EmployeeDirectory({
  employees,
  filteredEmployees,
  filter,
  search,
  loading,
  selectedIds,
  byProgram,
  onFilterChange,
  onSearchChange,
  onNew,
  onOpen,
  onToggle,
  onToggleVisible,
}: Props) {
  const allVisibleSelected = filteredEmployees.length > 0 && filteredEmployees.every(employee => selectedIds.includes(employee.id));

  return (
    <section className="page-content directory-page">
      <div className="page-heading-row">
        <div><p className="eyebrow">ПЕДАГОГИЧЕСКИЙ СОСТАВ</p><h1>Сотрудники</h1><p className="page-subtitle">Карточки сотрудников, статус заполнения и защищённый экспорт</p></div>
        <button className="button button-primary" onClick={onNew}><Plus size={19} />Добавить сотрудника</button>
      </div>
      <div className="directory-toolbar">
        <div className="filter-tabs">
          <button className={filter === "ALL" ? "selected" : ""} onClick={() => onFilterChange("ALL")}>Все <span>{employees.length}</span></button>
          {(Object.keys(programLabels) as ProgramCode[]).map(program => <button key={program} className={filter === program ? "selected" : ""} onClick={() => onFilterChange(program)}>{programLabels[program]} <span>{byProgram[program]}</span></button>)}
        </div>
        <label className="search-box"><Search size={19} /><input value={search} onChange={event => onSearchChange(event.target.value)} placeholder="Поиск по ФИО или должности" /></label>
      </div>
      {loading ? <div className="panel empty-state">Загружаем карточки сотрудников…</div> : filteredEmployees.length ? <>
        <section className="export-toolbar panel" aria-label="Групповой экспорт карточек">
          <label className="export-select-all"><input type="checkbox" checked={allVisibleSelected} onChange={onToggleVisible} /><span>Выбрать всех в текущем списке</span></label>
          <div className="export-toolbar-actions"><span className="export-selection-count">Выбрано: {selectedIds.length}</span><span className="export-page-note">Каждая карточка — с новой страницы</span><EmployeeExportButtons employeeIds={selectedIds} group /></div>
        </section>
        <div className="employee-grid">
          {filteredEmployees.map(employee => {
            const selected = selectedIds.includes(employee.id);
            return <article className={`employee-card ${selected ? "selected-for-export" : ""}`} key={employee.id}>
              <button className="employee-card-open" type="button" onClick={() => onOpen(employee.id)}>
                <div className="employee-card-top"><span className="avatar">{initials(employee)}</span><span className={`status-badge ${employee.status}`}>{employee.status === "complete" ? "Заполнена" : "Черновик"}</span></div>
                <strong className="employee-card-name">{fullName(employee)}</strong><span className="employee-card-role">{employee.position || "Должность не указана"}</span>
                <div className="tag-row">{employee.programs.length ? employee.programs.map(code => <span className="program-tag" key={code}>{programLabels[code]}</span>) : <span className="program-tag empty-tag">Программа не выбрана</span>}</div>
                <div className="card-progress-label"><span>Заполнение анкеты</span><strong>{completionPercent(employee)}%</strong></div>
                <div className="progress-track small-progress"><span style={{ width: `${completionPercent(employee)}%` }} /></div>
                <div className="employee-card-bottom"><span>Обновлено {humanDate(employee.updatedAt)}</span><ChevronRight size={19} /></div>
              </button>
              <div className="employee-card-export">
                <label className="export-select-one"><input type="checkbox" checked={selected} onChange={() => onToggle(employee.id)} /><span>Выбрать</span></label>
                <EmployeeExportButtons employeeIds={[employee.id]} compact />
              </div>
            </article>;
          })}
        </div>
      </> : <div className="panel empty-state"><span className="empty-icon"><Search size={23} /></span><strong>Сотрудники не найдены</strong><span>Измените фильтр или поисковый запрос.</span><button className="text-button" onClick={() => { onFilterChange("ALL"); onSearchChange(""); }}>Сбросить фильтры</button></div>}
    </section>
  );
}
