import { ArrowLeft, Plus, Trash2 } from "lucide-react";
import type { EmployeeFormData, EmployeeStatus } from "@shared/employees";
import { programLabels, programCodes } from "@shared/employees";

type Props = {
  value: EmployeeFormData;
  errors: Record<string, string>;
  saving: boolean;
  serverError?: string;
  editing: boolean;
  publicMode?: boolean;
  onChange: (next: EmployeeFormData) => void;
  onSave: (status: EmployeeStatus) => void;
  onCancel: () => void;
};

const educationOptions = [
  ["higher", "Высшее"],
  ["secondary_special", "Среднее специальное"],
  ["none", "Без образования"],
] as const;
const categoryOptions = [
  ["first", "Первая"],
  ["highest", "Высшая"],
  ["none", "Отсутствует"],
] as const;

function Field({ label, hint, error, required, children }: { label: string; hint?: string; error?: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div className={`field ${error ? "field-error" : ""}`}>
      <label className="field-label">{label}{required && <span className="required-mark"> *</span>}</label>
      {hint && <p className="field-hint">{hint}</p>}
      {children}
      {error && <span className="field-error-text">{error}</span>}
    </div>
  );
}

export default function EmployeeForm({ value, errors, saving, serverError, editing, publicMode = false, onChange, onSave, onCancel }: Props) {
  const set = <K extends keyof EmployeeFormData>(key: K, next: EmployeeFormData[K]) => onChange({ ...value, [key]: next });
  const setCourse = (index: number, field: keyof EmployeeFormData["courses"][number], next: string | number | null) => {
    const courses = value.courses.map((course, row) => row === index ? { ...course, [field]: next } : course);
    set("courses", courses);
  };
  const addCourse = () => set("courses", [...value.courses, { monthYear: "", courseName: "", hours: null }]);
  const removeCourse = (index: number) => set("courses", value.courses.filter((_, row) => row !== index));
  const toggleProgram = (program: (typeof programCodes)[number]) => {
    set("programs", value.programs.includes(program) ? value.programs.filter(item => item !== program) : [...value.programs, program]);
  };
  const errorFor = (key: string) => errors[key];
  const title = editing ? "Редактирование анкеты" : publicMode ? "Анкета педагогического работника" : "Новая анкета";

  return (
    <div className="form-page">
      <button className="back-link" type="button" onClick={onCancel}><ArrowLeft size={19} /> {publicMode ? "Очистить и начать заново" : "К списку сотрудников"}</button>
      <div className="form-heading">
        <div>
          <p className="eyebrow">{publicMode ? "ОТКРЫТАЯ ФОРМА ЗАПОЛНЕНИЯ" : "КАРТОЧКА СОТРУДНИКА"}</p>
          <h1>{title}</h1>
          <p className="page-subtitle">{publicMode ? "Заполните сведения и отправьте анкету. Сохранённые данные доступны только утверждённым пользователям." : "Заполните сведения о педагогическом работнике. Поля со звёздочкой нужны для завершения анкеты."}</p>
        </div>
        <span className="form-number">{editing ? "РЕДАКТИРОВАНИЕ" : publicMode ? "ОТПРАВКА АНКЕТЫ" : "НОВАЯ ЗАПИСЬ"}</span>
      </div>

      {serverError && <div className="alert alert-error" role="alert">{serverError}</div>}
      {Object.keys(errors).length > 0 && <div className="alert alert-error" role="alert">{publicMode ? "Проверьте выделенные поля, затем отправьте анкету." : "Проверьте выделенные поля. Анкету можно пока сохранить как черновик."}</div>}

      <form className="employee-form" onSubmit={event => { event.preventDefault(); onSave("complete"); }}>
        <section className="form-section">
          <div className="section-title"><span className="section-index">01</span><div><h2>Общие сведения</h2><p>Программы, должность и профессиональная область</p></div></div>
          <Field label="Общеобразовательные программы" required error={errorFor("programs")} hint="Можно выбрать несколько вариантов">
            <div className="choice-grid program-grid">
              {programCodes.map(program => <label key={program} className={`choice-card ${value.programs.includes(program) ? "selected" : ""}`}>
                <input type="checkbox" checked={value.programs.includes(program)} onChange={() => toggleProgram(program)} />
                <span className="custom-check" />
                <span><strong>{programLabels[program]}</strong><small>{program === "NOO" ? "Начальное общее образование" : program === "OOO" ? "Основное общее образование" : "Среднее общее образование"}</small></span>
              </label>)}
            </div>
          </Field>
          <div className="field-grid three-columns">
            <Field label="Фамилия" required error={errorFor("surname")}><input className="control" value={value.surname} maxLength={120} onChange={event => set("surname", event.target.value)} placeholder="Иванов" /></Field>
            <Field label="Имя" required error={errorFor("firstName")}><input className="control" value={value.firstName} maxLength={120} onChange={event => set("firstName", event.target.value)} placeholder="Иван" /></Field>
            <Field label="Отчество"><input className="control" value={value.middleName} maxLength={120} onChange={event => set("middleName", event.target.value)} placeholder="Иванович" /></Field>
          </div>
          <div className="field-grid two-columns">
            <Field label="Занимаемая должность" required error={errorFor("position")} hint="Например: учитель, воспитатель, психолог, педагог-психолог"><input className="control" value={value.position} maxLength={180} onChange={event => set("position", event.target.value)} placeholder="Учитель" /></Field>
            <Field label="Преподаваемые предметы, курсы, модули" required error={errorFor("subjects")} hint="Например: русский язык, литература"><input className="control" value={value.subjects} maxLength={500} onChange={event => set("subjects", event.target.value)} placeholder="Русский язык, литература" /></Field>
          </div>
        </section>

        <section className="form-section">
          <div className="section-title"><span className="section-index">02</span><div><h2>Образование и квалификация</h2><p>Уровень образования и сведения о категории</p></div></div>
          <Field label="Уровень образования" required error={errorFor("education")}>
            <div className="radio-list">
              {educationOptions.map(([key, label]) => <label className="radio-option" key={key}><input type="radio" name="education" checked={value.education === key} onChange={() => set("education", key)} /><span className="radio-dot" />{label}</label>)}
            </div>
          </Field>
          <Field label="Квалификационная категория" required error={errorFor("qualificationCategory")}>
            <div className="radio-list radio-list-inline">
              {categoryOptions.map(([key, label]) => <label className="radio-option" key={key}><input type="radio" name="qualificationCategory" checked={value.qualificationCategory === key} onChange={() => set("qualificationCategory", key)} /><span className="radio-dot" />{label}</label>)}
            </div>
          </Field>
          {(value.qualificationCategory === "first" || value.qualificationCategory === "highest") && <div className="conditional-panel">
            <div className="conditional-heading"><span className="conditional-dot" />Реквизиты присвоения категории</div>
            <div className="field-grid two-columns">
              <Field label="Дата присвоения" required error={errorFor("categoryAssignedAt")}><input className="control" type="date" value={value.categoryAssignedAt} onChange={event => set("categoryAssignedAt", event.target.value)} /></Field>
              <Field label="Номер приказа" required error={errorFor("categoryOrderNumber")}><input className="control" value={value.categoryOrderNumber} maxLength={120} onChange={event => set("categoryOrderNumber", event.target.value)} placeholder="Например, № 125-к" /></Field>
            </div>
          </div>}
        </section>

        <section className="form-section">
          <div className="section-title"><span className="section-index">03</span><div><h2>Учёная степень и звание</h2><p>Заполняется, если применимо</p></div></div>
          <Field label="Учёная степень">
            <div className="radio-list radio-list-inline">
              <label className="radio-option"><input type="radio" name="degree" checked={value.academicDegree === null} onChange={() => onChange({ ...value, academicDegree: null, degreeField: "", degreeDiploma: "" })} /><span className="radio-dot" />Не указана</label>
              <label className="radio-option"><input type="radio" name="degree" checked={value.academicDegree === "candidate"} onChange={() => set("academicDegree", "candidate")} /><span className="radio-dot" />Кандидат наук</label>
              <label className="radio-option"><input type="radio" name="degree" checked={value.academicDegree === "doctor"} onChange={() => set("academicDegree", "doctor")} /><span className="radio-dot" />Доктор наук</label>
            </div>
          </Field>
          {value.academicDegree && <div className="conditional-panel">
            <div className="conditional-heading"><span className="conditional-dot" />Сведения о степени</div>
            <div className="field-grid two-columns">
              <Field label="Отрасль науки" required error={errorFor("degreeField")}><input className="control" value={value.degreeField} maxLength={180} onChange={event => set("degreeField", event.target.value)} placeholder="Педагогические науки" /></Field>
              <Field label="Диплом: серия, номер или реквизиты" required error={errorFor("degreeDiploma")}><input className="control" value={value.degreeDiploma} maxLength={180} onChange={event => set("degreeDiploma", event.target.value)} placeholder="Диплом кандидата наук" /></Field>
            </div>
          </div>}
          <Field label="Учёное звание">
            <div className="radio-list radio-list-inline">
              <label className="radio-option"><input type="radio" name="title" checked={value.academicTitle === null} onChange={() => set("academicTitle", null)} /><span className="radio-dot" />Не указано</label>
              <label className="radio-option"><input type="radio" name="title" checked={value.academicTitle === "associate_professor"} onChange={() => set("academicTitle", "associate_professor")} /><span className="radio-dot" />Доцент</label>
              <label className="radio-option"><input type="radio" name="title" checked={value.academicTitle === "professor"} onChange={() => set("academicTitle", "professor")} /><span className="radio-dot" />Профессор</label>
            </div>
          </Field>
        </section>

        <section className="form-section">
          <div className="section-title"><span className="section-index">04</span><div><h2>Награды и достижения</h2><p>Необязательные сведения</p></div></div>
          <div className="field-grid two-columns">
            <Field label="Государственные и ведомственные награды" hint="Почётные звания, например «Заслуженный учитель РФ», знаки отличия"><textarea className="control textarea" value={value.stateAwards} maxLength={1200} onChange={event => set("stateAwards", event.target.value)} placeholder="Укажите награды и почётные звания" /></Field>
            <Field label="Спортивные звания и награды"><textarea className="control textarea" value={value.sportsAwards} maxLength={1200} onChange={event => set("sportsAwards", event.target.value)} placeholder="Укажите спортивные звания и награды" /></Field>
          </div>
        </section>

        <section className="form-section courses-section">
          <div className="section-title"><span className="section-index">05</span><div><h2>Повышение квалификации</h2><p>За последние три года: 2024, 2025, 2026</p></div></div>
          <div className="warning-banner"><span className="warning-mark">!</span><div><strong>Курсы менее 24 часов не указывать (!!!)</strong><span>Укажите курсы за 2024–2025-2026 годы. Продолжительность каждого курса должна составлять не менее 24 часов.</span></div></div>
          <div className="course-table-wrap">
            <div className="course-table-head"><span>Месяц, год</span><span>Название курса</span><span>Количество часов</span><span /></div>
            {value.courses.length === 0 && <div className="courses-empty">Сведения о курсах пока не добавлены.</div>}
            {value.courses.map((course, index) => <div className="course-row" key={index}>
              <div><label className="sr-only" htmlFor={`course-period-${index}`}>Месяц и год курса</label><input id={`course-period-${index}`} className="control" type="text" maxLength={16} value={course.monthYear} onChange={event => setCourse(index, "monthYear", event.target.value)} placeholder="июль, 2026" autoComplete="off" /><span className="field-error-text">{errorFor(`courses.${index}.monthYear`)}</span></div>
              <div><label className="sr-only" htmlFor={`course-name-${index}`}>Название курса</label><input id={`course-name-${index}`} className="control" value={course.courseName} maxLength={300} onChange={event => setCourse(index, "courseName", event.target.value)} placeholder="Название программы повышения квалификации" /><span className="field-error-text">{errorFor(`courses.${index}.courseName`)}</span></div>
              <div><label className="sr-only" htmlFor={`course-hours-${index}`}>Количество часов</label><input id={`course-hours-${index}`} className={`control ${course.hours !== null && course.hours < 24 ? "invalid" : ""}`} type="number" min="24" step="1" value={course.hours ?? ""} onChange={event => setCourse(index, "hours", event.target.value === "" ? null : Number(event.target.value))} placeholder="От 24" /><span className="field-error-text">{errorFor(`courses.${index}.hours`)}</span></div>
              <button className="icon-button remove-course" type="button" onClick={() => removeCourse(index)} aria-label="Удалить строку курса"><Trash2 size={18} /></button>
            </div>)}
          </div>
          <button className="add-row-button" type="button" onClick={addCourse}><Plus size={18} /> Добавить курс</button>
        </section>

        <div className="form-footer">
          <div className="save-note">{publicMode ? "После отправки анкета поступит в закрытый раздел для утверждённых пользователей." : "Черновик можно сохранить без заполнения всех полей."}</div>
          <div className="form-actions">
            <button className="button button-secondary" type="button" onClick={onCancel} disabled={saving}>{publicMode ? "Очистить форму" : "Отмена"}</button>
            {!publicMode && <button className="button button-outline" type="button" onClick={() => onSave("draft")} disabled={saving}>{saving ? "Сохранение…" : "Сохранить черновик"}</button>}
            <button className="button button-primary" type="submit" disabled={saving}>{saving ? "Сохранение…" : publicMode ? "Отправить анкету" : editing ? "Сохранить анкету" : "Завершить анкету"}</button>
          </div>
        </div>
      </form>
    </div>
  );
}
